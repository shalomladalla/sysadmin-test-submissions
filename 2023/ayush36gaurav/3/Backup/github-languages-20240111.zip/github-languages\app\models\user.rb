class User < ApplicationRecord
end
