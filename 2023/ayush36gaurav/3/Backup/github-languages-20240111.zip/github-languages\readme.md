Tiny little ruby on rails website that crawls though your public repos to find out what your favourite languages are. GitHub crawler logic can be found under app/services/github_client.rb.
